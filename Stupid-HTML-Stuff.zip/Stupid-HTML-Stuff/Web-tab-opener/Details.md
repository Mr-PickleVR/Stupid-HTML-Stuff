it spam opens new tabs, make sure to allow pop-ups and redirects, otherwise it won't work
