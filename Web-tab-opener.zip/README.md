# Stupid-HTML-Stuff
Just some stupid html things me and a friend made
